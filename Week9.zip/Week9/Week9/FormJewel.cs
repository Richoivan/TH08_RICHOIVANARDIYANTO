﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week9
{
    public partial class FormJewel : Form
    {
        FormMain formmain;
        public FormJewel()
        {
            InitializeComponent();
        }
        public void FormThis(FormMain formthis)
        {
            this.formmain = formthis;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            formmain.ItemAdd("Gold Diamond Necklace", 1100000);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            formmain.ItemAdd("Silver Necklace", 450000);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            formmain.ItemAdd("Infinity Necklace", 600000);
        }
    }
}
