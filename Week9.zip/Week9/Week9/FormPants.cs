﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week9
{
    public partial class FormPants : Form
    {
        FormMain formmain;
        public FormPants()
        {
            InitializeComponent();
        }
        public void FormThis(FormMain formthis)
        {
            this.formmain = formthis;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            formmain.ItemAdd("Short Pants", 65000);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            formmain.ItemAdd("White Knee Pants", 90000);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            formmain.ItemAdd("Short Cargo Pants", 120000);
        }
    }
}
